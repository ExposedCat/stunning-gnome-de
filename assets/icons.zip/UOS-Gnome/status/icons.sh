# mv network-wireless-signal-low-symbolic.svg network-wireless-signal-weak-symbolic.svg
# mv network-wireless-signal-medium-symbolic.svg network-wireless-signal-ok-symbolic.svg
# mv network-wireless-signal-high-symbolic.svg network-wireless-signal-good-symbolic.svg
# mv network-wireless-signal-full-symbolic.svg network-wireless-signal-excellent-symbolic.svg
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/network-wireless-signal-weak-symbolic.svg network-wireless-signal-weak-symbolic.svg
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/network-wireless-signal-ok-symbolic.svg network-wireless-signal-ok-symbolic.svg
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/network-wireless-signal-good-symbolic.svg network-wireless-signal-good-symbolic.svg
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/network-wireless-signal-excellent-symbolic.svg network-wireless-signal-excellent-symbolic.svg
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-0-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-10-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-20-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-30-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-40-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-50-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-60-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-70-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-80-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-90-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-100-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-0-charging-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-10-charging-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-20-charging-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-30-charging-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-40-charging-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-50-charging-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-60-charging-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-70-charging-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-80-charging-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-90-charging-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-level-100-charged-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-empty-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-low-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-medium-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-good-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-full-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-caution-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-missing-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-empty-charging-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-low-charging-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-medium-charging-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-good-charging-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-full-charged-symbolic.svg .
# cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/battery-caution-charging-symbolic.svg .
# cp /home/exposedcat/Downloads/Uos-fulldistro-icons/status/20/audio-volume-muted-symbolic.svg .
# cp /home/exposedcat/Downloads/Uos-fulldistro-icons/status/20/audio-volume-low-symbolic.svg .
# cp /home/exposedcat/Downloads/Uos-fulldistro-icons/status/20/audio-volume-medium-symbolic.svg .
# cp /home/exposedcat/Downloads/Uos-fulldistro-icons/status/20/audio-volume-high-symbolic.svg .
# cp /home/exposedcat/Downloads/Uos-fulldistro-icons/status/20/audio-volume-muted-symbolic.svg audio-volume-muted-symbolic-dark.svg
# cp /home/exposedcat/Downloads/Uos-fulldistro-icons/status/20/audio-volume-low-symbolic.svg audio-volume-low-symbolic-dark.svg
# cp /home/exposedcat/Downloads/Uos-fulldistro-icons/status/20/audio-volume-medium-symbolic.svg audio-volume-medium-symbolic-dark.svg
# cp /home/exposedcat/Downloads/Uos-fulldistro-icons/status/20/audio-volume-high-symbolic.svg audio-volume-high-symbolic-dark.svg

cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/display-brightness-symbolic.svg .
cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/display-brightness-off-symbolic.svg .
cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/display-brightness-low-symbolic.svg .
cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/display-brightness-medium-symbolic.svg .
cp /home/exposedcat/.icons/Tela-black-dark/symbolic/status/display-brightness-high-symbolic.svg .