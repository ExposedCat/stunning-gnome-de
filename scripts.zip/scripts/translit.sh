#!/bin/bash
TEXT=$(xclip -o)
TRS=`echo $TEXT | sed "y/qwertyuiop[]asdfghjkl;\'\\zxcvbnm,.\//йцукенгшщзхъфывапролджэ\\ячсмитьбю./"`
TRS=`echo $TRS | sed 'y/QWERTYUIOP{}:"|ASDFGHJKLZXCVBNM<>?/ЙЦУКЕНГШЩЗХЪЖЭ\/ФЫВАПРОЛДЯЧСМИТЬБЮ,/'`
TRS=`echo $TRS | sed 'y/~!@#$%^&/Ё!"№;%:?/'`
zenity --info --text "$TRS"