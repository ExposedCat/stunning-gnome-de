formula="$(zenity --text-info \
--title="TeX to image" \
--editable)"
# formula=$(xclip -o)
# formula=$(bash ~/Shell/escape-special.bash "$formula")
tex_formula=$(echo "$formula" | sed -z 's/\n/\\\\/g')
image=$(bash ~/Shell/pnglatex -d 4000 -f "\\\\${tex_formula}")
xclip -selection clipboard -t image/png -i $image
rm $image
