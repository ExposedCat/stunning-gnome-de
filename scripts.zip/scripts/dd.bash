#!/bin/bash
"sudo if=$1 | pv -s 2G | sudo dd of=$2"
