#!/bin/bash
string=$1
special=$'`\\!@#$%^&*()-_+={}|[];\':",.<>?/ '
for ((i=0; i < ${#special}; i++)); do
    char="${special:i:1}"
    printf -v q_char '%q' "$char"
    if [[ "$char" != "$q_char" ]]; then
        escaped="\\$char"
        string="${string//$escaped/$escaped}"
    fi
done
echo $string
