# !/bin/bash
apt search "^$1$"