import re
import subprocess

temps = subprocess.check_output("sensors | grep °C", shell=True).decode("utf-8")
results = re.findall("(.+):\s+\+(\d+)\.\d+°C\s+\((?:.+)?crit = \+(\d+)\.\d+°C\)", temps, flags = re.MULTILINE)
def gets():
    for temp in results:
        if int(temp[1]) >= int(temp[2]):
            print(temp[0])
            return
    print("false")
gets()
