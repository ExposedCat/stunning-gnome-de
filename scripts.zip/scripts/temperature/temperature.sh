#!/bin/bash
tmp="$(python3 /home/mew/Shell/temperature/tmp.py)"
if [ "$tmp" != "false" ]; then
    notify-send "${tmp} ПЕРЕГРЕЛСЯ" "Модуль ${tmp} перегрелся. Понизьте нагрузку или выключите ПК" -t 60000 -u critical
fi
